
#include<iostream>
using namespace std;
int main() {
	int i;
	i = 1;
	while (i<=5) {
		cout << i << endl;
		i = i+1;
	}
	return 0;
}

