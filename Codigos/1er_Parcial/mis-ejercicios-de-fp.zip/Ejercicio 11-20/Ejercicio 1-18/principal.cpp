#include <iostream>
using namespace std;

int main() {
    int X; // Definir X como entero
    
    // para X desde 1 hasta 10 hacer
    for (X = 1; X <= 10; X++) {
        if (X % 2 == 0) {
            cout << X << " "; // Mostrar X
        }
    }
    
    return 0;
}