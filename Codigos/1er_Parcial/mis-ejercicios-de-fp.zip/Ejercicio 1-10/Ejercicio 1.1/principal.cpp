#include <iostream>
using namespace std;
int main() {
    double N_1, N_2, M;
    cout << "Ingresa un primer numero real: ";
    cin >> N_1;  
    cout << "Ingresa el segundo numero real: ";
    cin >> N_2;
    M = (N_1 + N_2) / 2;
    cout << "La media entre ellos es: " << M << endl;
    return 0;
}