#include <iostream>
using namespace std;

int main() {
    int N_1, N_2, i, j;
    bool esPrimo;

    cout << "Ingrese el primer numero (limite inferior): ";
    cin >> N_1;

    cout << "Ingrese el segundo numero (limite superior): ";
    cin >> N_2;

    cout << "Numeros primos entre " << N_1 << " y " << N_2 << ":" << endl;

    if (N_1 > N_2) {
        int temp = N_1;
        N_1 = N_2;
        N_2 = temp;
    }
    for (i = N_1; i <= N_2; i++) {
        esPrimo = true;
        
        if (i <= 1) {
            esPrimo = false;
        } else {
            for (j = 2; j <= i/2; j++) {
                if (i % j == 0) {
                    esPrimo = false;
                    break;
                }
            }
        }
        if (esPrimo) {
            cout << i << " ";
        }
    }
    cout << endl;
    return 0;
}