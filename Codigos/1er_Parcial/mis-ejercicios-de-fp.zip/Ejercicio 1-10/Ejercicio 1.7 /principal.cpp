#include <iostream>
using namespace std;

int main() {
    float N_1, Sum = 0, Med, Max, Min;
    int contador = 0;
    bool N_0 = true;
    do {
        cout << "Ingrese una altura: "; // Ingresa un número negativo para terminar
        cin >> N_1;
        if (N_1 >= 0) {
            if (N_0) {
                Max = N_1;
                Min = N_1;
                N_0 = false;
            } else {
                if (N_1 > Max) {
                    Max = N_1;
                }
                if (N_1 < Min) {
                    Min = N_1;
                }
            }
            Sum += N_1;
            contador++;
        }
    } while (N_1 >= 0);
    if (contador > 0) {
        Med = Sum / contador;
        cout << "Media de alturas: " << Med << endl;
        cout << "Altura máxima: " << Max << endl;
        cout << "Altura mínima: " << Min << endl;
    } else {
        cout << "No se ingresaron alturas válidas." << endl;
    }
    
    return 0;
}