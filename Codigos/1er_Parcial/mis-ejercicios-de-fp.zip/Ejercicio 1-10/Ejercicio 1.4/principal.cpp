#include<iostream>
using namespace std;
int main() {
	float n_1;
	cout << "Ingresa un numero entero mayor a 0: " << endl;
	cin >> n_1;
	if (((n_1>=0) && (n_1<10))) {
		cout << "Si esta en el intervalo" << endl;
	} else {
		cout << "No pertenece al intervalo" << endl;
	}
	return 0;
}

