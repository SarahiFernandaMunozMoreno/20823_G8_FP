#include<iostream>
using namespace std;
int main() {
	float anos;
	float dias;
	float horas;
	float meses;
	float minutos;
	int opcion;
	float semanas;
	float valor;
	cout << "Conversor de Unidades de Tiempo" << endl;
	cout << "1. Segundos a Minutos" << endl;
	cout << "2. Minutos a Horas" << endl;
	cout << "3. Horas a Días" << endl;
	cout << "4. Días a Semanas" << endl;
	cout << "5. Semanas a Meses" << endl;
	cout << "6. Meses a Años" << endl;
	cin >> opcion;
	switch (opcion) {
	case 1:
		cout << "Ingrese el valor en segundos: " << endl;
		cin >> valor;
		minutos = valor/60;
		cout << valor << " segundos son " << minutos << " minutos" << endl;
		break;
	case 2:
		cout << "Ingrese el valor en minutos: " << endl;
		cin >> valor;
		horas = valor/60;
		cout << valor << " minutos son " << horas << " horas" << endl;
		break;
	case 3:
		cout << "Ingrese el valor en horas: " << endl;
		cin >> valor;
		dias = valor/24;
		cout << valor << " horas son " << dias << " días" << endl;
		break;
	case 4:
		cout << "Ingrese el valor en días: " << endl;
		cin >> valor;
		semanas = valor/7;
		cout << valor << " días son " << semanas << " semanas" << endl;
		break;
	case 5:
		cout << "Ingrese el valor en semanas: " << endl;
		cin >> valor;
		meses = valor/4;
		cout << valor << " semanas son " << meses << " meses" << endl;
		break;
	case 6:
		cout << "Ingrese el valor en meses: " << endl;
		cin >> valor;
		anos = valor/12;
		cout << valor << " meses son " << anos << " años" << endl;
		break;
	default:
		cout << "Opción inválida" << endl;
	}
	return 0;
}