#include <iostream>
#include <cmath> // Para la función sqrt()
using namespace std;

int main() {
    double N_1, i;
    bool r1;
    cout << "Ingresar un entero mayor a 0: ";
    cin >> N_1;
    i = sqrt(N_1);
    r1 = (i > 1) && (pow(i, 2) < N_1);
    if (i > 1) {
        cout << "La Raiz es: " << i << endl;
    }

    return 0;
}